AMRI Stage 5B.3 source audit bundle
Package: 1.1.2
Base: 3324f28fbcdc928475ce2d01690af86d80798918
Branch: feat/amri-stage4-three-prepared-participants
Read-only: no checkout files, refs, index or working tree were changed.
Contains baseline-source.tar.gz (src + architecture continuity/ADRs), audit-report.json and SHA256SUMS.
